var question = "What is Superman's real name?"
var answer = prompt(question);
alert("You answered " + answer);
