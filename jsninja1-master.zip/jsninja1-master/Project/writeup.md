chapter 8

-------------

Add boxes to click on to select answer ... or an input to put answer into

chapter 9
-------------




chapter 10
-------------

add use strict
add console log statements to functions
add tests - check right and wrong answers

chapter 11
-------------

Add random function
choose questions at random
Change to options

chapter 12
-------------

new quiz constructor function

chapter 13
-------------




chapter 14
-------------



Chapter 15
------------

Add view module
controller module?
Write gulp task to test, minify and deploy


