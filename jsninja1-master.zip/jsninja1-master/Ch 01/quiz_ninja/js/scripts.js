// welcome the user
alert("Welcome to Quiz Ninja!");
