# Downloadable code: contents #

1. excanvas_r3: ExplorerCanvas Release 3 (Google)

For IE functionality for `canvas`, this allows developers to add a single script tag in existing pages. (2009)



2. Canvas primer. 